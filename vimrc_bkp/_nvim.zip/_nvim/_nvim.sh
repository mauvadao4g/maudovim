#!/bin/bash

INIT="$HOME/.config/nvim/init.vim"

cp $INIT .
