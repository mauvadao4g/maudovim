#!/bin/bash
# MAUVADAO
# VER: 1.0.0

echo -e "\e[1;33mBranch nova\e[0m"
