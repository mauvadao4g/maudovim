# MAUDAVPN
  <img alt="Welcome" title="Welcome" src="img/maudavpn-telegram.jpg" />
  Menu
## Descrição do Projeto

<p align="center"></p>
<h1 align="center">
    <a href="https://t.me/maudavpn">🔗 Canal telegram</a><br>
    <a href="https://t.me/maud4vpn">🧠 Grupo Telegram</a>
</h1>
<p align="center">🚀 Automatizando a instalção e configuraçao do vim e nvim.</p>
<br>


# ✨ **Editor de Terminal: VIM** ✨

🌟 Torne seu terminal mais poderoso com o editor de texto **VIM**! 🖋️

## 📥 **Como instalar o VIM**

1️⃣ Abra seu terminal.

2️⃣ Execute **um dos comandos abaixo** para instalar rapidamente:

### Pré-requisitos

### 🎲 Rodando a aplicação

```bash
# Clone este repositório
$ git clone https://github.com/mauvadao4g/maudovim.git

# Acesse a pasta do projeto no terminal/cmd
$ cd maudovim

# Instale as dependências
$ bash install.sh

# Execute a aplicação
$ vim

## Pronto.
```

### Comandos Intalação via link
curl -sL "https://raw.githubusercontent.com/mauvadao4g/maudovim/refs/heads/main/instalador" | bash

OU

bash <(curl -sL "https://raw.githubusercontent.com/mauvadao4g/maudovim/refs/heads/main/instalador")


🔧 Pronto! Agora você pode aproveitar o VIM para codificar com estilo no seu terminal. 🚀

💡 Dica: Experimente personalizar seu VIM para deixá-lo com a sua cara! 😎
