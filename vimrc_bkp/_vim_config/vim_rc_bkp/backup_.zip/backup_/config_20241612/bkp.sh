#!/bin/bash

echo "Copiando  snippets"
cp $HOME/.vim/autoload/plug/start/vim-snippets/UltiSnips/sh.snippets .

echo "Copiando vimrc"
cp $HOME/.vimrc vimrc
